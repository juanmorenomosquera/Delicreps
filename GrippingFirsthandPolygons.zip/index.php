<? 
$campo=$_POST['campo'];
$campo = trim($campo);
?>
<!DOCTYPE html>
<html lang="en">
<? include 'head.php'?>
<body>
  
<? include 'presentacion.php'?>

<div class="container">
   <div class="row">
  <?include 'columna1.php';
  include 'columna2.php';
?>
   </div>
</div>

</body>
</html>