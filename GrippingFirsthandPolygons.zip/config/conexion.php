<?
$host="bq65enjdwcprd74d7hkq-mysql.services.clever-cloud.com";
$bd="bq65enjdwcprd74d7hkq";
$user="uyzevohe0cjnst2e";
$pwd="vpmQxeLV6ZXFrpxFxLP2";

$con=mysqli_connect($host,$user,$pwd,$bd) or 
  die(" Problemas en la conexión");
?>