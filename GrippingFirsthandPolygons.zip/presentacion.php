<center><div class="jumbtron-center">
  <h1>tienda de muebles.</h1>
  <p>Fé y Alegría aures 2.</p></center>
  <p>
      <center><img src="img/muebleria.png">
  </p>
</div></center>