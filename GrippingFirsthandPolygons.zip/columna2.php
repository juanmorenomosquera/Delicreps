<div class="col-sm-6">
<?
  $campo=$_POST['campo'];

// Incluir la conexión
if(strlen ($campo)>0){
  $sql="SELECT codigo,nombre,categoria,medidas,precio,color,codimagen,estado

FROM tblmuebles where nombre like '$campo%'";
  include 'config/conexion.php';
$registro=mysqli_query($con,$sql) or die('Error en sql');
echo '<table border="1"><tr><td>codigo</td><td>nombre</td><td>categoria</td><td>medidas</td><td>precio</td>
<td>color</td><td>codimagen</td><td>estado</td></tr>';
while($r=mysqli_fetch_array($registro)) {
 echo "<tr><td>".$r['codigo']."</td>
   <td>".$r['nombre']."</td><td>".$r['categoria']."</td><td>".$r['medidas']."</td><td>".$r['precio']."</td><td>".$r['color']."</td><td><img src=img/".$r['codimagen']."></td><td>".$r['estado']."></td>
</tr>" ;
   
}
  
}
  
  
?>
</table>
</div>