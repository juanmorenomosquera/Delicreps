<!DOCTYPE html>
<html lang="en">
<? include 'head.php'?>
<body>
  
<? include 'presentacion.php'?>

<div class="container">
   <div class="row">
     Crear muebles
     <div class="col">
    <form action="guardarMueble.php" method="post"> 
      
    <input type="text" name="nombre"  class="form-control" placeholder="nombre del mueble">
    <select name="categoria">
      <option value ="">Seleccione el tipo       </option>
      <option value ="silla"> Silla    </option> 
      <option value ="sofas"> Sofás </option>
      <option value ="cama"> Cama </option>
      <option value ="estanteria">Estantería </option>
      <option value ="PUF">Puf</option>
      <option value ="mesa">Mesa</option>
      <option value="escritorio">Escritorio</option>
    
    </select>
      <input type="text" name="medidas"  class="form-control" placeholder="alto x ancho x profundidas">
     <input type="number" name="precio"  class="form-control" placeholder="Valor">
      <input type="text" name="color"  class="form-control" placeholder="Color">
      <input type="text" name="codimagen"  class="form-control" placeholder="Imagen">
      
      <input type="text" name="estado"  class="form-control" placeholder="estado del mueble">
      <select name ="estado">
      <option value ="">Seleccione el estado de los materiales del mueble mueble </option>
      <option value ="nuevo">nuevo</option>
      <option value ="usado">segunda mano</option>
      
    </form>
      </select>
      <br><button type="submit">Guardar </button> 
   </div>
     <div class="col">
        listado de muebles
      </div>
</div>

</body>
</html>