<div class="col-sm-4">
  <h3>Búsqueda de muebles</h3>
  <div> 
   <form class="form-group" action="index.php" method="post">
     <input type="text" name="campo" class="form-group"
       placeholder="Ingrese un criterio de busqueda">
     <button type="submit" class="btn btn-success form-group">Buscar</button>
     <a href="crearMueble.php" class="btn btn-success form-group">Crear</a>
   </form>
  </div>
  
</div>